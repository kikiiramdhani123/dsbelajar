<?= $this->extend('layout/template'); ?>
<?= $this->section('konten'); ?>
<section id="cekTugas">
    <?php if (session()->getFlashdata('pesan')) : ?>
        <div class="alert alert-success alert-dismissible">
            <a href="" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong><?= session()->getFlashdata('pesan'); ?></strong>
        </div>
    <?php endif; ?>
    <table class="table table-dark table-hover">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Guru</th>
                <th scope="col">Mapel</th>
                <th scope="col">Deskripsi Tugas</th>
                <th scope="col">Batas Pengumpulan</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <?php $i = 1 ?>
                <?php foreach ($dataTugas as $d) : ?>
                    <td><?= $i++; ?></td>
                    <td><?= $d['guru']; ?></td>
                    <td><?= $d['mapel']; ?></td>
                    <td><?= $d['deskripsiTugas']; ?></td>
                    <td><?= $d['batasPengumpulan']; ?></td>
                <?php endforeach; ?>
            </tr>
        </tbody>
    </table>
</section>
<?= $this->endSection(); ?>