<?= $this->extend('layout/template'); ?>
<?= $this->section('konten'); ?>
<div class="mt-3 mb-3">
    <img src="/img/jadwal.jpeg" alt="">
</div>
<div>
    <img src="/img/kodeguru.jpeg" alt="">
</div>
<?= $this->endSection(); ?>