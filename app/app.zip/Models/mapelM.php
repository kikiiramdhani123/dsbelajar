<?php

namespace App\Models;

use CodeIgniter\Model;

class mapelM extends Model
{
    protected $table = 'mapel';
    protected $allowedFields = ['namaMapel'];
}
